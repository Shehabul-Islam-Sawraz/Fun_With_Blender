import logging


PREFS = {}
DATA = {
  'images available': {}
}

log = logging.basicConfig(level=logging.INFO)
